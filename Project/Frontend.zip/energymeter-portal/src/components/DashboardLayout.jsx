import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import { useAuth } from '../context/AuthContext';

const titles = {
  '/consumer/dashboard': 'Consumer Dashboard',
  '/consumer/submit': 'Submit Meter Reading',
  '/consumer/history': 'Reading History',
  '/consumer/analytics': 'Consumption Analytics',
  '/consumer/profile': 'Profile',
  '/admin/dashboard': 'Admin Dashboard',
  '/admin/readings': 'Meter Readings',
  '/admin/analytics': 'Admin Analytics',
  '/admin/profile': 'Profile',
};

// Shared layout for logged-in pages: sidebar (left) + top header + page content (<Outlet />).
export default function DashboardLayout() {
  const { user } = useAuth();
  const { pathname } = useLocation();
  const initials = user.name.split(' ').map((p) => p[0]).slice(0, 2).join('');

  return (
    <div className="shell">
      <Sidebar />
      <div className="main">
        <header className="topbar">
          <h1 className="topbar-title">{titles[pathname] || 'EnergyMeter'}</h1>
          <div className="topbar-user">
            <div className="topbar-user-text">
              <strong>{user.name}</strong>
              <span>{user.role === 'admin' ? 'Utility Administrator' : `Consumer - ${user.meterId}`}</span>
            </div>
            <div className="avatar">{initials}</div>
          </div>
        </header>
        <main className="content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
