import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Icon from '../components/Icon';
import { landingPreview } from '../data/mockData';

const features = [
  { icon: 'bolt', title: 'Digital Meter Reading', text: 'Consumers submit their current meter reading through a simple validated form instead of paper slips.' },
  { icon: 'table', title: 'Reading Management', text: 'Administrators search, filter, verify and audit every reading in one centralized data grid.' },
  { icon: 'chart', title: 'Consumption Analytics', text: 'Consumption is calculated from readings and turned into comparisons, history and usage insights.' },
  { icon: 'shield', title: 'Role-Based Access', text: 'Consumers and administrators get separate dashboards and can only see what their role allows.' },
];
const steps = ['Consumer submits reading', 'Reading is stored', 'Reading can be verified', 'Consumption is calculated', 'Analytics are generated'];

export default function Home() {
  const max = Math.max(...landingPreview.bars);
  return (
    <div className="landing">
      <Navbar />

      <section className="hero">
        <div className="hero-inner">
          <div className="hero-text">
            <span className="eyebrow">Energy &amp; Utilities</span>
            <h1>Smart Meter Reading Management &amp; Analytics</h1>
            <p>
              EnergyMeter digitizes meter reading submission, management and energy-consumption analysis, so consumers understand
              their usage and utility administrators can verify readings and analyze utility-wide data.
            </p>
            <div className="btn-row">
              <Link to="/login" className="btn btn-primary">Get Started</Link>
              <Link to="/login" className="btn btn-outline">Login</Link>
            </div>
          </div>

          {/* Clean illustration: a meter display + a small bar preview (sample data) */}
          <div className="meter-card" aria-hidden="true">
            <div className="meter-top">
              <span>Meter MTR-10234</span>
              <span className="badge badge-verified">Active</span>
            </div>
            <div className="meter-display">
              {landingPreview.meterValue.split('').map((d, i) => <span key={i}>{d}</span>)}
              <em>kWh</em>
            </div>
            <div className="mini-bars">
              {landingPreview.bars.map((b, i) => (
                <div key={i} className={`mini-bar ${i === landingPreview.bars.length - 1 ? 'current' : ''}`} style={{ height: `${(b / max) * 100}%` }} />
              ))}
            </div>
            <div className="meter-foot">Recent monthly consumption (sample data)</div>
          </div>
        </div>
      </section>

      <section id="features" className="section">
        <h2 className="section-title">Features</h2>
        <div className="feature-grid">
          {features.map((f) => (
            <div className="feature-card" key={f.title}>
              <span className="feature-icon"><Icon name={f.icon} size={20} /></span>
              <h3>{f.title}</h3>
              <p>{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="about" className="section section-alt">
        <h2 className="section-title">How it works</h2>
        <div className="steps">
          {steps.map((s, i) => (
            <div className="step" key={s}>
              <span className="step-num">{i + 1}</span>
              <span>{s}</span>
            </div>
          ))}
        </div>
        <p className="about-text">
          The portal is a DBMS project that manages meter readings for the energy and utilities sector. Readings are stored
          per consumer, consumption is always calculated as <strong>current reading &minus; previous reading</strong>, and
          the stored history powers the analytics.
        </p>
      </section>

      <footer className="footer">
        <div>
          <strong>ENERGYMETER</strong>
          <p>Meter Reading Management &amp; Analytics Portal for Energy &amp; Utilities</p>
        </div>
        <p>College DBMS project &middot; React, Node.js, Express, MySQL, Sequelize, JWT, Chart.js</p>
      </footer>
    </div>
  );
}
