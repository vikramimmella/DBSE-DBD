// Display formatting helpers (dates use ISO strings "YYYY-MM-DD" everywhere in the data).
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function formatDate(iso) {
  if (!iso) return '-';
  const [y, m, d] = iso.split('-').map(Number);
  return `${MONTHS[m - 1]} ${d}, ${y}`;
}

export const formatNumber = (n) => Number(n).toLocaleString('en-US', { maximumFractionDigits: 1 });
export const formatKwh = (n) => `${formatNumber(n)} kWh`;
export const formatSignedKwh = (n) => `${n > 0 ? '+' : ''}${formatNumber(n)} kWh`;

export function formatPercent(p) {
  if (p === null || p === undefined) return 'N/A';
  return `${p > 0 ? '+' : ''}${p.toFixed(1)}%`;
}

export function monthKeyLabel(key) {
  const [y, m] = key.split('-').map(Number);
  return `${MONTHS[m - 1]} ${y}`;
}

const pad = (n) => String(n).padStart(2, '0');
export function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function isValidISODate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return false;
  const [y, m, d] = value.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.getFullYear() === y && date.getMonth() === m - 1 && date.getDate() === d;
}
