// Analytics: turns raw meter readings into the numbers shown on the analytics pages.
// Rule: REJECTED readings are excluded from analytics (Verified + Pending are counted).
import {
  calculateAverageConsumption,
  calculateHighestConsumption,
  calculateLowestConsumption,
  calculatePercentageChange,
  calculateOverallAverage,
  detectUnusualConsumption,
} from './calculations';

const MONTH_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTH_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

export const acceptedReadings = (readings) => readings.filter((r) => r.status !== 'Rejected');

export function getYears(readings) {
  return [...new Set(readings.map((r) => Number(r.date.slice(0, 4))))].sort((a, b) => b - a);
}

// Readings that fall inside the selected filters (yearly view ignores the year filter).
function inScope(readings, period, year) {
  return acceptedReadings(readings).filter((r) => period === 'yearly' || Number(r.date.slice(0, 4)) === Number(year));
}

/**
 * Groups readings into periods (months / quarters / years) and adds up consumption.
 * Returns e.g. [{ label: 'Sep', fullLabel: 'September', total: 330 }, ...] oldest -> newest.
 */
export function buildPeriodSeries(readings, period, year) {
  const buckets = {};
  inScope(readings, period, year).forEach((r) => {
    const y = Number(r.date.slice(0, 4));
    const m = Number(r.date.slice(5, 7));
    let key, label, fullLabel;
    if (period === 'monthly') {
      key = y * 100 + m; label = MONTH_SHORT[m - 1]; fullLabel = MONTH_FULL[m - 1];
    } else if (period === 'quarterly') {
      const q = Math.ceil(m / 3);
      key = y * 10 + q; label = `Q${q}`; fullLabel = `Q${q} ${y}`;
    } else {
      key = y; label = String(y); fullLabel = String(y);
    }
    if (!buckets[key]) buckets[key] = { key, label, fullLabel, total: 0 };
    buckets[key].total += r.consumption;
  });
  return Object.values(buckets).sort((a, b) => a.key - b.key);
}

/** Everything the consumer analytics page needs, derived from readings. */
export function getConsumerAnalytics(myReadings, allReadings, period, year) {
  const series = buildPeriodSeries(myReadings, period, year);
  const totals = series.map((s) => s.total);
  const current = series[series.length - 1] || null;
  const previous = series[series.length - 2] || null;

  const average = calculateAverageConsumption(totals);
  const highest = calculateHighestConsumption(totals);
  const lowest = calculateLowestConsumption(totals);
  const change = calculatePercentageChange(current?.total, previous?.total);

  // Unusual consumption: compare the latest period with the average of the EARLIER periods.
  const earlier = totals.slice(0, -1);
  const baseline = earlier.length ? calculateAverageConsumption(earlier) : null;
  const unusual = current && baseline !== null ? { ...detectUnusualConsumption(current.total, baseline), baseline } : null;

  // Personal vs overall: average consumption per reading (per month) inside the selected scope.
  const myAverage = calculateAverageConsumption(inScope(myReadings, period, year));
  const overallAverage = calculateOverallAverage(inScope(allReadings, period, year));

  return {
    series, current, previous, average, highest, lowest, change, unusual, myAverage, overallAverage,
    highestItem: series.find((s) => s.total === highest) || null,
    lowestItem: series.find((s) => s.total === lowest) || null,
  };
}

/** Utility-wide numbers for the admin analytics page. */
export function getAdminAnalytics(readings, consumers) {
  const accepted = acceptedReadings(readings);
  const totalConsumption = accepted.reduce((s, r) => s + r.consumption, 0);
  const averageConsumption = calculateAverageConsumption(accepted);
  const highestValue = calculateHighestConsumption(accepted);
  const highestReading = accepted.find((r) => r.consumption === highestValue) || null;

  // Overall consumption by month (all consumers together).
  const monthly = {};
  accepted.forEach((r) => {
    const key = r.date.slice(0, 7);
    monthly[key] = (monthly[key] || 0) + r.consumption;
  });
  const byMonth = Object.keys(monthly).sort().map((key) => {
    const [y, m] = key.split('-').map(Number);
    return { label: `${MONTH_SHORT[m - 1]} ${String(y).slice(2)}`, total: monthly[key] };
  });

  // Per-consumer totals and averages.
  const perConsumer = consumers.map((c) => {
    const mine = accepted.filter((r) => r.consumerId === c.id);
    return { id: c.id, name: c.name, total: mine.reduce((s, r) => s + r.consumption, 0), average: calculateAverageConsumption(mine) };
  });
  const topConsumers = [...perConsumer].sort((a, b) => b.total - a.total).slice(0, 5);

  const statusCounts = { Verified: 0, Pending: 0, Rejected: 0 };
  readings.forEach((r) => { statusCounts[r.status] += 1; });

  return {
    totalConsumption, averageConsumption, highestReading, highestValue, byMonth, perConsumer, topConsumers, statusCounts,
    overallAverage: calculateOverallAverage(accepted),
    consumerCount: consumers.length,
    pendingCount: statusCounts.Pending,
  };
}
