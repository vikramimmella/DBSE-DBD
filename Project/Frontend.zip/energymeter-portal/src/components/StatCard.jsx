import Icon from './Icon';

// tone: default | green | amber | red  (colours the small icon and, optionally, the sub text)
export default function StatCard({ label, value, sub, icon, tone = 'default', subTone }) {
  return (
    <div className="stat-card">
      <div className="stat-head">
        <span className="stat-label">{label}</span>
        {icon && <span className={`stat-icon tone-${tone}`}><Icon name={icon} size={16} /></span>}
      </div>
      <div className="stat-value">{value}</div>
      {sub && <div className={`stat-sub ${subTone ? `text-${subTone}` : ''}`}>{sub}</div>}
    </div>
  );
}
