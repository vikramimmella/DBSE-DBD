// Verified = green, Pending = amber, Rejected = red (styles in index.css)
export default function StatusBadge({ status }) {
  return <span className={`badge badge-${status.toLowerCase()}`}>{status}</span>;
}
