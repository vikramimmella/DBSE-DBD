import { useState } from 'react';
import Input from './Input';
import Button from './Button';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';

const roleLabels = { consumer: 'Consumer', admin: 'Utility Administrator' };

// Shared by the consumer and admin profile pages. Editing only changes local React state (demo).
export default function ProfileCard() {
  const { user, updateProfile } = useAuth();
  const { notify } = useNotification();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: user.name, email: user.email });
  const [errors, setErrors] = useState({});

  function save() {
    const next = {};
    if (!form.name.trim()) next.name = 'Name is required.';
    if (!/^\S+@\S+\.\S+$/.test(form.email)) next.email = 'Enter a valid email address.';
    setErrors(next);
    if (Object.keys(next).length) return;
    updateProfile({ name: form.name.trim(), email: form.email.trim() });
    setEditing(false);
    notify('Profile updated successfully.');
  }

  const rows = [
    ['Name', user.name],
    ['Email', user.email],
    ...(user.meterId ? [['Meter ID', user.meterId]] : []),
    ['Role', roleLabels[user.role]],
  ];

  return (
    <div className="card profile-card">
      <div className="card-header">
        <h3 className="card-title">Account Details</h3>
        {!editing && <Button variant="outline" size="sm" onClick={() => setEditing(true)}>Edit Profile</Button>}
      </div>

      {editing ? (
        <div className="profile-form">
          <Input id="p-name" label="Name" value={form.name} error={errors.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <Input id="p-email" label="Email" value={form.email} error={errors.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <div className="btn-row">
            <Button onClick={save}>Save Changes</Button>
            <Button variant="outline" onClick={() => { setEditing(false); setErrors({}); setForm({ name: user.name, email: user.email }); }}>Cancel</Button>
          </div>
        </div>
      ) : (
        <div className="detail-grid">
          {rows.map(([label, value]) => (
            <div className="detail-item" key={label}>
              <span className="detail-label">{label}</span>
              <span className="detail-value">{value}</span>
            </div>
          ))}
          <div className="detail-item">
            <span className="detail-label">Account Status</span>
            <span className="badge badge-verified">{user.status}</span>
          </div>
        </div>
      )}
    </div>
  );
}
