import { useMemo, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useReadings } from '../../context/ReadingContext';
import Input from '../../components/Input';
import Select from '../../components/Select';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Button from '../../components/Button';
import ReadingDetailsModal from '../../components/ReadingDetailsModal';
import { filterReadings, getMonthOptions, sortReadingsDesc } from '../../utils/filters';
import { formatDate, formatKwh, formatNumber } from '../../utils/format';

const statusOptions = ['All', 'Verified', 'Pending', 'Rejected'].map((s) => ({ value: s, label: s === 'All' ? 'All statuses' : s }));

export default function ReadingHistory() {
  const { user } = useAuth();
  const { readings } = useReadings();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [month, setMonth] = useState('All');
  const [selected, setSelected] = useState(null);

  const mine = useMemo(() => sortReadingsDesc(readings.filter((r) => r.consumerId === user.id)), [readings, user.id]);
  const rows = useMemo(() => filterReadings(mine, { search, status, month }), [mine, search, status, month]);

  const columns = [
    { key: 'date', label: 'Date', render: (r) => formatDate(r.date) },
    { key: 'meterId', label: 'Meter ID' },
    { key: 'previousReading', label: 'Previous Reading', align: 'right', render: (r) => formatNumber(r.previousReading) },
    { key: 'currentReading', label: 'Current Reading', align: 'right', render: (r) => formatNumber(r.currentReading) },
    { key: 'consumption', label: 'Consumption', align: 'right', render: (r) => formatKwh(r.consumption) },
    { key: 'status', label: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { key: 'actions', label: 'Actions', render: (r) => <Button variant="ghost" size="sm" onClick={() => setSelected(r)}>View Details</Button> },
  ];

  return (
    <>
      <div className="card">
        <div className="toolbar">
          <Input id="search" label="Search" placeholder="Search by meter ID, date or status" value={search} onChange={(e) => setSearch(e.target.value)} />
          <Select id="status" label="Status" options={statusOptions} value={status} onChange={(e) => setStatus(e.target.value)} />
          <Select id="month" label="Month" options={getMonthOptions(mine)} value={month} onChange={(e) => setMonth(e.target.value)} />
        </div>
        <p className="table-count">Showing {rows.length} of {mine.length} readings</p>
        <DataTable columns={columns} rows={rows} empty={mine.length === 0 ? 'No meter readings available.' : 'No readings match your search.'} />
      </div>

      {selected && <ReadingDetailsModal reading={selected} consumerName={user.name} onClose={() => setSelected(null)} />}
    </>
  );
}
