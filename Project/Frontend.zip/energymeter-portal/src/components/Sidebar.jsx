import { NavLink, useNavigate } from 'react-router-dom';
import Icon from './Icon';
import { useAuth } from '../context/AuthContext';

const consumerLinks = [
  { to: '/consumer/dashboard', label: 'Dashboard', icon: 'dashboard' },
  { to: '/consumer/submit', label: 'Submit Reading', icon: 'submit' },
  { to: '/consumer/history', label: 'Reading History', icon: 'history' },
  { to: '/consumer/analytics', label: 'Analytics', icon: 'chart' },
  { to: '/consumer/profile', label: 'Profile', icon: 'user' },
];
const adminLinks = [
  { to: '/admin/dashboard', label: 'Dashboard', icon: 'dashboard' },
  { to: '/admin/readings', label: 'Meter Readings', icon: 'table' },
  { to: '/admin/analytics', label: 'Analytics', icon: 'chart' },
  { to: '/admin/profile', label: 'Profile', icon: 'user' },
];

export default function Sidebar() {
  const { role, logout } = useAuth();
  const navigate = useNavigate();
  const links = role === 'admin' ? adminLinks : consumerLinks;

  function handleLogout() {
    logout();
    navigate('/login');
  }

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <span className="brand-mark"><Icon name="bolt" size={18} /></span>
        <div>
          <div className="brand-name">ENERGYMETER</div>
          <div className="brand-sub">{role === 'admin' ? 'Utility Admin' : 'Consumer Portal'}</div>
        </div>
      </div>
      <nav className="sidebar-nav">
        {links.map((l) => (
          <NavLink key={l.to} to={l.to} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            <Icon name={l.icon} /> {l.label}
          </NavLink>
        ))}
      </nav>
      <button className="nav-link logout" onClick={handleLogout}>
        <Icon name="logout" /> Logout
      </button>
    </aside>
  );
}
