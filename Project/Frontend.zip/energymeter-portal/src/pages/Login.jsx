import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import Input from '../components/Input';
import Button from '../components/Button';
import Icon from '../components/Icon';
import { useAuth } from '../context/AuthContext';

const demoEmails = { consumer: 'consumer@example.com', admin: 'admin@example.com' };

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState('consumer');
  const [email, setEmail] = useState(demoEmails.consumer);
  const [password, setPassword] = useState('demo123');
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  // Already logged in -> go straight to the right dashboard
  if (user) return <Navigate to={`/${user.role}/dashboard`} replace />;

  function chooseRole(next) {
    setRole(next);
    setEmail(demoEmails[next]);
    setErrors({});
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const next = {};
    if (!/^\S+@\S+\.\S+$/.test(email)) next.email = 'Enter a valid email address.';
    if (!password.trim()) next.password = 'Password is required.';
    setErrors(next);
    if (Object.keys(next).length) return;

    setLoading(true);
    try {
      const loggedIn = await login({ email, password, role }); // demo login (api.login)
      navigate(`/${loggedIn.role}/dashboard`);
    } catch (err) {
      setErrors({ form: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page">
      <div className="login-card">
        <Link to="/" className="public-brand">
          <span className="brand-mark"><Icon name="bolt" size={18} /></span> ENERGYMETER
        </Link>
        <h1>Sign in to your portal</h1>
        <p className="muted">Meter Reading Management &amp; Analytics Portal</p>

        <div className="role-toggle">
          <button type="button" className={role === 'consumer' ? 'active' : ''} onClick={() => chooseRole('consumer')}>Consumer</button>
          <button type="button" className={role === 'admin' ? 'active' : ''} onClick={() => chooseRole('admin')}>Admin</button>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <Input id="email" label="Email" type="email" value={email} error={errors.email} onChange={(e) => setEmail(e.target.value)} />
          <Input id="password" label="Password" type="password" value={password} error={errors.password} onChange={(e) => setPassword(e.target.value)} />
          {errors.form && <div className="form-alert">{errors.form}</div>}
          <Button type="submit" className="btn-block" disabled={loading}>{loading ? 'Signing in...' : `Login as ${role === 'admin' ? 'Admin' : 'Consumer'}`}</Button>
        </form>

        <div className="demo-note">
          <strong>Demo login:</strong> this is a frontend demo. Use <code>consumer@example.com</code> or <code>admin@example.com</code> with any
          password. Real JWT authentication will be added with the backend.
        </div>
      </div>
    </div>
  );
}
