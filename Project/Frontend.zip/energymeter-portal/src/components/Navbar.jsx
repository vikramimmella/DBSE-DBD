import { Link } from 'react-router-dom';
import Icon from './Icon';

// Public website header (landing page).
export default function Navbar() {
  return (
    <header className="public-nav">
      <div className="nav-inner">
        <Link to="/" className="public-brand">
          <span className="brand-mark"><Icon name="bolt" size={18} /></span> ENERGYMETER
        </Link>
        <nav className="public-links">
          <Link to="/">Home</Link>
          <a href="/#features">Features</a>
          <a href="/#about">About</a>
          <Link to="/login" className="btn btn-primary btn-sm">Login</Link>
        </nav>
      </div>
    </header>
  );
}
