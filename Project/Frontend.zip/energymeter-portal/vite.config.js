import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Standard Vite + React setup. When the backend exists you can add a dev proxy here, e.g.
// server: { proxy: { '/api': 'http://localhost:5000' } }
export default defineConfig({
  plugins: [react()],
});
