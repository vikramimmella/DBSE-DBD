import ProfileCard from '../../components/ProfileCard';

export default function ConsumerProfile() {
  return <ProfileCard />;
}
