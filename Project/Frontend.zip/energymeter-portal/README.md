# EnergyMeter - Meter Reading Management & Analytics Portal (Frontend)

React + Vite frontend prototype (demo data, demo login). Backend (Node/Express/Sequelize/MySQL/JWT) will be added later.

## Run
    npm install
    npm run dev
Open the printed localhost URL (usually http://localhost:5173) in Chrome.

## Demo logins (any password)
- Consumer: consumer@example.com  (Vikram Immella, MTR-10234)
- Admin: admin@example.com

## Where things are
- Pages: src/pages (Home, Login, consumer/, admin/)
- Mock data: src/data/mockData.js
- Backend integration point: src/services/api.js (replace mock bodies with fetch/axios)
- Shared state: src/context (Auth, Reading, Notification)
- Calculations: src/utils/calculations.js, analytics: src/utils/analytics.js
