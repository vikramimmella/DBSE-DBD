import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useReadings } from '../../context/ReadingContext';
import { useNotification } from '../../context/NotificationContext';
import Input from '../../components/Input';
import Button from '../../components/Button';
import { calculateConsumption } from '../../utils/calculations';
import { sortReadingsDesc } from '../../utils/filters';
import { acceptedReadings } from '../../utils/analytics';
import { formatDate, formatKwh, isValidISODate, todayISO } from '../../utils/format';

export default function SubmitReading() {
  const { user } = useAuth();
  const { readings, addReading } = useReadings();
  const { notify } = useNotification();

  const [currentReading, setCurrentReading] = useState('');
  const [date, setDate] = useState(todayISO());
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  // "Previous reading" = the consumer's latest stored (non-rejected) reading.
  const latest = useMemo(
    () => sortReadingsDesc(acceptedReadings(readings.filter((r) => r.consumerId === user.id)))[0],
    [readings, user.id]
  );
  const previous = latest ? latest.currentReading : 0;

  // Live preview of the consumption once a valid number is typed.
  const typed = currentReading.trim() === '' ? NaN : Number(currentReading);
  const preview = Number.isFinite(typed) ? calculateConsumption(typed, previous) : null;

  function validate() {
    const next = {};
    if (currentReading.trim() === '') next.currentReading = 'Current reading is required.';
    else if (!Number.isFinite(typed)) next.currentReading = 'Current reading must be a number.';
    else if (typed < previous) next.currentReading = 'Current reading must be greater than or equal to the previous reading.';

    if (!date) next.date = 'Reading date is required.';
    else if (!isValidISODate(date)) next.date = 'Enter a valid date.';
    else if (date > todayISO()) next.date = 'Reading date cannot be in the future.';
    else if (latest && date < latest.date) next.date = `Reading date cannot be before the previous reading (${formatDate(latest.date)}).`;
    return next;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.keys(next).length) return;

    setSaving(true);
    await addReading({ consumerId: user.id, meterId: user.meterId, date, previousReading: previous, currentReading: typed });
    setSaving(false);
    notify('Meter reading submitted successfully.');
    setCurrentReading(''); // the new reading now becomes the "previous reading"
  }

  return (
    <div className="card form-card">
      <div className="card-header">
        <div>
          <h3 className="card-title">Submit Meter Reading</h3>
          <p className="card-sub">Enter the current value shown on your meter. Your reading will be stored as Pending until verified.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} noValidate>
        <div className="form-grid">
          <Input id="meter" label="Meter Number" value={user.meterId} readOnly />
          <Input id="date" label="Reading Date" type="date" max={todayISO()} value={date} error={errors.date} onChange={(e) => setDate(e.target.value)} />
          <Input id="prev" label="Previous Meter Reading (kWh)" value={latest ? formatKwh(previous) : 'No previous reading'} readOnly hint={latest ? `Recorded on ${formatDate(latest.date)}` : undefined} />
          <Input id="current" label="Current Meter Reading (kWh)" type="text" inputMode="decimal" placeholder="e.g. 12450" value={currentReading} error={errors.currentReading} onChange={(e) => setCurrentReading(e.target.value)} />
        </div>

        <div className="calc-box">
          <div><span>Previous Reading</span><strong>{formatKwh(previous)}</strong></div>
          <div><span>Current Reading</span><strong>{Number.isFinite(typed) ? formatKwh(typed) : '-'}</strong></div>
          <div className="calc-result">
            <span>Calculated Consumption</span>
            <strong>{preview === null ? '-' : formatKwh(preview)}</strong>
          </div>
        </div>

        <div className="btn-row">
          <Button type="submit" disabled={saving}>{saving ? 'Submitting...' : 'Submit Reading'}</Button>
          <Link to="/consumer/history" className="btn btn-outline">View Reading History</Link>
        </div>
      </form>
    </div>
  );
}
