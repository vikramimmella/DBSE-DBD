import { useMemo, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import { useAuth } from '../../context/AuthContext';
import { useReadings } from '../../context/ReadingContext';
import Select from '../../components/Select';
import StatCard from '../../components/StatCard';
import ChartCard from '../../components/ChartCard';
import EmptyState from '../../components/EmptyState';
import Icon from '../../components/Icon';
import { getConsumerAnalytics, getYears } from '../../utils/analytics';
import { UNUSUAL_THRESHOLD_PERCENT } from '../../utils/calculations';
import { baseOptions, COLORS } from '../../utils/chartSetup';
import { formatKwh, formatPercent, formatSignedKwh } from '../../utils/format';

const periodOptions = [
  { value: 'monthly', label: 'Monthly' },
  { value: 'quarterly', label: 'Quarterly' },
  { value: 'yearly', label: 'Yearly' },
];
const unitNames = { monthly: 'Month', quarterly: 'Quarter', yearly: 'Year' };

export default function ConsumptionAnalytics() {
  const { user } = useAuth();
  const { readings } = useReadings();

  const mine = useMemo(() => readings.filter((r) => r.consumerId === user.id), [readings, user.id]);
  const years = useMemo(() => getYears(mine), [mine]);
  const [period, setPeriod] = useState('monthly');
  const [year, setYear] = useState(2026);
  const [meter, setMeter] = useState(user.meterId);

  // All analytics are derived from the readings in state (so a newly submitted reading updates this page).
  const a = useMemo(() => getConsumerAnalytics(mine, readings, period, year), [mine, readings, period, year]);
  const unit = unitNames[period];

  if (mine.length === 0) return <EmptyState message="No meter readings available." />;

  const changeTone = a.change === null ? undefined : a.change > 0 ? 'red' : 'green';
  const diffKwh = a.current && a.previous ? a.current.total - a.previous.total : 0;
  const myVsOverall = a.myAverage - a.overallAverage;

  // Consumption History: bars per period (latest highlighted) + dashed average line
  const historyData = {
    labels: a.series.map((s) => s.label),
    datasets: [
      {
        type: 'bar',
        label: 'Consumption',
        data: a.series.map((s) => s.total),
        backgroundColor: a.series.map((_, i) => (i === a.series.length - 1 ? COLORS.green : COLORS.navyLight)),
        borderRadius: 4,
      },
      {
        type: 'line',
        label: `Average (${formatKwh(a.average)})`,
        data: a.series.map(() => a.average),
        borderColor: COLORS.navy,
        borderDash: [6, 4],
        borderWidth: 2,
        pointRadius: 0,
      },
    ],
  };

  return (
    <>
      <div className="filter-bar">
        <Select id="period" label="Period" options={periodOptions} value={period} onChange={(e) => setPeriod(e.target.value)} />
        <Select id="year" label="Year" options={years.map((y) => ({ value: y, label: String(y) }))} value={year} disabled={period === 'yearly'} onChange={(e) => setYear(Number(e.target.value))} />
        <Select id="meter" label="Meter" options={[{ value: user.meterId, label: `${user.meterId} (current meter)` }]} value={meter} onChange={(e) => setMeter(e.target.value)} />
      </div>
      <p className="note">Rejected readings are excluded from analytics.</p>

      {!a.current ? (
        <EmptyState message="No readings match the selected filters." />
      ) : (
        <>
          {/* 1. Summary cards */}
          <div className="stat-grid cols-5">
            <StatCard label={`Current ${unit} Consumption`} icon="bolt" tone="green" value={formatKwh(a.current.total)} sub={a.current.fullLabel} />
            <StatCard label={`Average Consumption per ${unit}`} icon="clock" value={formatKwh(a.average)} sub={`Over ${a.series.length} ${unit.toLowerCase()}(s)`} />
            <StatCard label="Highest Consumption" icon="alert" tone="red" value={formatKwh(a.highest)} sub={a.highestItem?.fullLabel} />
            <StatCard label="Lowest Consumption" icon="chart" tone="green" value={formatKwh(a.lowest)} sub={a.lowestItem?.fullLabel} />
            <StatCard label={`${unit}-to-${unit} Change`} icon="chart" tone="amber" value={formatPercent(a.change)} sub={a.previous ? `vs ${a.previous.fullLabel}` : 'No earlier period'} subTone={changeTone} />
          </div>

          {/* 2. Current vs previous period */}
          <div className="grid-2">
            <div className="card">
              <div className="card-header"><h3 className="card-title">This {unit} vs Previous {unit}</h3></div>
              {a.previous ? (
                <div className="compare-panel">
                  <div><span>Current {unit}</span><strong>{formatKwh(a.current.total)}</strong></div>
                  <div><span>Previous {unit}</span><strong>{formatKwh(a.previous.total)}</strong></div>
                  <div><span>Difference</span><strong className={`text-${changeTone}`}>{formatSignedKwh(diffKwh)}</strong></div>
                  <div><span>Percentage Change</span><strong className={`text-${changeTone}`}>{formatPercent(a.change)}</strong></div>
                  <p className="card-sub">
                    {diffKwh > 0 ? 'Your consumption increased' : diffKwh < 0 ? 'Your consumption decreased' : 'Your consumption did not change'} compared with the previous {unit.toLowerCase()}.
                  </p>
                </div>
              ) : (
                <EmptyState message="At least two periods are needed for a comparison." />
              )}
            </div>
            <ChartCard title="Comparison chart" subtitle="Total consumption in kWh" height={280}>
              {a.previous && (
                <Bar
                  options={baseOptions()}
                  data={{
                    labels: [`Previous ${unit} (${a.previous.label})`, `Current ${unit} (${a.current.label})`],
                    datasets: [{ label: 'Consumption', data: [a.previous.total, a.current.total], backgroundColor: [COLORS.grey, COLORS.green], borderRadius: 4, maxBarThickness: 90 }],
                  }}
                />
              )}
            </ChartCard>
          </div>

          {/* 3. Consumption history / pattern */}
          <ChartCard title="Consumption History" subtitle={`Consumption per ${unit.toLowerCase()} compared with your average (latest ${unit.toLowerCase()} highlighted)`} height={320}>
            <Bar options={baseOptions({ legend: true })} data={historyData} />
          </ChartCard>

          {/* 4. Usage insights (calculated from the data) */}
          <div className="card">
            <div className="card-header"><h3 className="card-title">Usage Insights</h3></div>
            <div className="insight-grid">
              <div className="insight"><span>Highest Consumption</span><strong>{a.highestItem?.fullLabel}</strong><em>{formatKwh(a.highest)}</em></div>
              <div className="insight"><span>Lowest Consumption</span><strong>{a.lowestItem?.fullLabel}</strong><em>{formatKwh(a.lowest)}</em></div>
              <div className="insight"><span>Average Consumption</span><strong>{formatKwh(a.average)}</strong><em>per {unit.toLowerCase()}</em></div>
            </div>
          </div>

          {/* 5. Unusual consumption (simple threshold rule, not AI/ML) */}
          {a.unusual ? (
            a.unusual.isUnusual ? (
              <div className="alert-card alert-warning">
                <div className="alert-title"><Icon name="alert" size={20} /> Unusual Consumption Detected</div>
                <p>
                  Your {a.current.fullLabel} consumption is {a.unusual.percentAbove.toFixed(1)}% higher than your recent average
                  (rule: more than {UNUSUAL_THRESHOLD_PERCENT}% above average).
                </p>
                <div className="alert-figures">
                  <div><span>Current</span><strong>{formatKwh(a.current.total)}</strong></div>
                  <div><span>Average</span><strong>{formatKwh(a.unusual.baseline)}</strong></div>
                  <div><span>Difference</span><strong>{formatSignedKwh(a.unusual.difference)}</strong></div>
                </div>
              </div>
            ) : (
              <div className="alert-card alert-ok">
                <div className="alert-title"><Icon name="check" size={20} /> Consumption is within your normal range.</div>
                <p>
                  Your {a.current.fullLabel} consumption ({formatKwh(a.current.total)}) is not more than {UNUSUAL_THRESHOLD_PERCENT}% above your
                  recent average of {formatKwh(a.unusual.baseline)}.
                </p>
              </div>
            )
          ) : (
            <div className="alert-card alert-ok">
              <div className="alert-title">Not enough history to check for unusual consumption.</div>
            </div>
          )}

          {/* 6. Personal vs overall average */}
          <div className="grid-2">
            <div className="card">
              <div className="card-header"><h3 className="card-title">Your Consumption vs Overall Average</h3></div>
              <div className="compare-panel">
                <div><span>Your average</span><strong>{formatKwh(a.myAverage)}</strong></div>
                <div><span>Overall average</span><strong>{formatKwh(a.overallAverage)}</strong></div>
                <div><span>Difference</span><strong className={`text-${myVsOverall > 0 ? 'red' : 'green'}`}>{formatSignedKwh(myVsOverall)}</strong></div>
                <p className="card-sub">Your average monthly consumption compared with the overall average in the available utility data (demonstration consumers).</p>
              </div>
            </div>
            <ChartCard title="Comparison chart" subtitle="Average monthly consumption (kWh)" height={260}>
              <Bar
                options={baseOptions()}
                data={{
                  labels: ['My Average', 'Overall Average'],
                  datasets: [{ label: 'Average consumption', data: [a.myAverage, a.overallAverage], backgroundColor: [COLORS.green, COLORS.navy], borderRadius: 4, maxBarThickness: 90 }],
                }}
              />
            </ChartCard>
          </div>
        </>
      )}
    </>
  );
}
