import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useReadings } from '../../context/ReadingContext';
import StatCard from '../../components/StatCard';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import { calculateAverageConsumption } from '../../utils/calculations';
import { sortReadingsDesc } from '../../utils/filters';
import { acceptedReadings } from '../../utils/analytics';
import { formatDate, formatKwh, formatNumber } from '../../utils/format';

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
}

export default function ConsumerDashboard() {
  const { user } = useAuth();
  const { readings } = useReadings();

  // All numbers below are derived from the reading state - nothing is hard-coded here.
  const mine = useMemo(() => sortReadingsDesc(readings.filter((r) => r.consumerId === user.id)), [readings, user.id]);
  const counted = useMemo(() => acceptedReadings(mine), [mine]); // rejected readings are ignored
  const latest = counted[0];
  const average = calculateAverageConsumption(counted);

  const columns = [
    { key: 'date', label: 'Date', render: (r) => formatDate(r.date) },
    { key: 'meterId', label: 'Meter ID' },
    { key: 'previousReading', label: 'Previous Reading', align: 'right', render: (r) => formatNumber(r.previousReading) },
    { key: 'currentReading', label: 'Current Reading', align: 'right', render: (r) => formatNumber(r.currentReading) },
    { key: 'consumption', label: 'Consumption', align: 'right', render: (r) => formatKwh(r.consumption) },
    { key: 'status', label: 'Status', render: (r) => <StatusBadge status={r.status} /> },
  ];

  return (
    <>
      <div className="page-intro">
        <div>
          <h2>{greeting()}, {user.name.split(' ')[0]}</h2>
          <p className="muted">Monitor your meter readings and understand your energy consumption.</p>
        </div>
        <Link to="/consumer/submit" className="btn btn-primary">Submit New Reading</Link>
      </div>

      <div className="stat-grid cols-4">
        <StatCard label="Current Meter Reading" icon="bolt" tone="green" value={latest ? formatKwh(latest.currentReading) : '-'} sub={latest ? `As of ${formatDate(latest.date)}` : 'No readings yet'} />
        <StatCard label="Previous Reading" icon="history" value={latest ? formatKwh(latest.previousReading) : '-'} sub="Reading before the latest one" />
        <StatCard label="Current Month Consumption" icon="chart" tone="amber" value={latest ? formatKwh(latest.consumption) : '-'} sub="Current - previous reading" />
        <StatCard label="Average Monthly Consumption" icon="clock" value={formatKwh(average)} sub={`Across ${counted.length} readings`} />
      </div>

      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Recent Readings</h3>
          <Link to="/consumer/history" className="btn btn-outline btn-sm">View All Readings</Link>
        </div>
        <DataTable columns={columns} rows={mine.slice(0, 5)} empty="No meter readings available." />
      </div>
    </>
  );
}
