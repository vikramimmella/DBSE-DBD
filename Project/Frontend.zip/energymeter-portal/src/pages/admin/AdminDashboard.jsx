import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useReadings } from '../../context/ReadingContext';
import { useNotification } from '../../context/NotificationContext';
import StatCard from '../../components/StatCard';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Button from '../../components/Button';
import ReadingDetailsModal from '../../components/ReadingDetailsModal';
import { calculateAverageConsumption } from '../../utils/calculations';
import { sortReadingsDesc } from '../../utils/filters';
import { acceptedReadings } from '../../utils/analytics';
import { formatDate, formatKwh, formatNumber } from '../../utils/format';

export default function AdminDashboard() {
  const { consumers, readings, getConsumerName, updateReadingStatus } = useReadings();
  const { notify } = useNotification();
  const [selected, setSelected] = useState(null);

  const recent = useMemo(() => sortReadingsDesc(readings).slice(0, 6), [readings]);
  const pending = readings.filter((r) => r.status === 'Pending').length;
  const average = calculateAverageConsumption(acceptedReadings(readings));

  async function review(reading, status) {
    await updateReadingStatus(reading.id, status);
    setSelected(null);
    if (status === 'Verified') notify('Reading verified successfully.');
    else notify('Reading rejected.', 'error');
  }

  const columns = [
    { key: 'consumer', label: 'Consumer', render: (r) => getConsumerName(r.consumerId) },
    { key: 'meterId', label: 'Meter ID' },
    { key: 'date', label: 'Date', render: (r) => formatDate(r.date) },
    { key: 'currentReading', label: 'Current Reading', align: 'right', render: (r) => formatNumber(r.currentReading) },
    { key: 'consumption', label: 'Consumption', align: 'right', render: (r) => formatKwh(r.consumption) },
    { key: 'status', label: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { key: 'action', label: 'Action', render: (r) => <Button variant={r.status === 'Pending' ? 'primary' : 'ghost'} size="sm" onClick={() => setSelected(r)}>{r.status === 'Pending' ? 'Review' : 'View'}</Button> },
  ];

  return (
    <>
      <div className="page-intro">
        <div>
          <h2>Utility Overview</h2>
          <p className="muted">Monitor meter readings and overall system activity. (Demonstration data.)</p>
        </div>
      </div>

      <div className="stat-grid cols-4">
        <StatCard label="Total Consumers" icon="users" tone="green" value={formatNumber(consumers.length)} sub="Registered consumers" />
        <StatCard label="Total Meter Readings" icon="table" value={formatNumber(readings.length)} sub="All stored readings" />
        <StatCard label="Pending Verification" icon="clock" tone="amber" value={formatNumber(pending)} sub="Waiting for admin review" />
        <StatCard label="Average Consumption" icon="chart" value={formatKwh(average)} sub="Per reading (excl. rejected)" />
      </div>

      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Recent Meter Readings</h3>
          <Link to="/admin/readings" className="btn btn-outline btn-sm">View All Readings</Link>
        </div>
        <DataTable columns={columns} rows={recent} empty="No meter readings available." />
      </div>

      {selected && (
        <ReadingDetailsModal
          reading={selected}
          consumerName={getConsumerName(selected.consumerId)}
          canReview
          onClose={() => setSelected(null)}
          onVerify={(r) => review(r, 'Verified')}
          onReject={(r) => review(r, 'Rejected')}
        />
      )}
    </>
  );
}
