import { createContext, useCallback, useContext, useState } from 'react';
import Notification from '../components/Notification';

// Lets any page call notify('message', 'success' | 'error' | 'info') to show a toast.
const NotificationContext = createContext(null);

export function NotificationProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const notify = useCallback((message, type = 'success') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 3500);
  }, []);

  return (
    <NotificationContext.Provider value={{ notify }}>
      {children}
      <Notification toasts={toasts} />
    </NotificationContext.Provider>
  );
}

export const useNotification = () => useContext(NotificationContext);
