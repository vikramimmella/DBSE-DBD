import { formatDate, monthKeyLabel } from './format';

/** Newest first (date, then meter value as a tie-breaker because meter values only increase). */
export function sortReadingsDesc(readings) {
  return [...readings].sort((a, b) => b.date.localeCompare(a.date) || b.currentReading - a.currentReading);
}

/** Options for the "month" filter: only months that actually have readings. */
export function getMonthOptions(readings) {
  const keys = [...new Set(readings.map((r) => r.date.slice(0, 7)))].sort().reverse();
  return [{ value: 'All', label: 'All months' }, ...keys.map((k) => ({ value: k, label: monthKeyLabel(k) }))];
}

/**
 * Search + status + month filtering shared by the consumer and admin tables.
 * Search matches meter ID, date (ISO and formatted), status and consumer name.
 */
export function filterReadings(readings, { search = '', status = 'All', month = 'All' }, getName = () => '') {
  const term = search.trim().toLowerCase();
  return readings.filter((r) => {
    if (status !== 'All' && r.status !== status) return false;
    if (month !== 'All' && !r.date.startsWith(month)) return false;
    if (!term) return true;
    const text = [r.meterId, r.date, formatDate(r.date), r.status, getName(r.consumerId)].join(' ').toLowerCase();
    return text.includes(term);
  });
}
