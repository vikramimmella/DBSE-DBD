export default function EmptyState({ message = 'No meter readings available.' }) {
  return <div className="empty">{message}</div>;
}
