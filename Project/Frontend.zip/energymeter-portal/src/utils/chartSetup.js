// Registers the Chart.js pieces we use (Chart.js v4 is tree-shakeable) and shares common styling.
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, BarController, LineElement, PointElement,
  LineController, ArcElement, Tooltip, Legend,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, BarController, LineElement, PointElement, LineController, ArcElement, Tooltip, Legend);
ChartJS.defaults.font.family = "Inter, 'Segoe UI', system-ui, sans-serif";
ChartJS.defaults.color = '#475569';

export const COLORS = { navy: '#0f2a43', navyLight: '#7c93ad', green: '#1f9d6b', grey: '#cbd5e1', amber: '#d99a0b', red: '#c0392b' };

/** Shared options for bar/line charts: responsive, labelled axes, tooltips in kWh. */
export function baseOptions({ yTitle = 'Consumption (kWh)', legend = false, horizontal = false } = {}) {
  const valueAxis = { beginAtZero: true, title: { display: true, text: yTitle }, grid: { color: '#eef2f6' } };
  const labelAxis = { grid: { display: false } };
  return {
    responsive: true,
    maintainAspectRatio: false,
    indexAxis: horizontal ? 'y' : 'x',
    plugins: {
      legend: { display: legend, position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } },
      tooltip: {
        callbacks: {
          label: (ctx) => ` ${ctx.dataset.label}: ${Number(horizontal ? ctx.parsed.x : ctx.parsed.y).toLocaleString()} kWh`,
        },
      },
    },
    scales: horizontal ? { x: valueAxis, y: labelAxis } : { y: valueAxis, x: labelAxis },
  };
}
