import Modal from './Modal';
import Button from './Button';
import StatusBadge from './StatusBadge';
import { formatDate, formatKwh } from '../utils/format';

// Shared "Meter Reading Details" popup.
// Consumers only view; admins (canReview) get Verify / Reject buttons for Pending readings.
export default function ReadingDetailsModal({ reading, consumerName, canReview = false, onClose, onVerify, onReject }) {
  const isPending = reading.status === 'Pending';
  const items = [
    ['Consumer', consumerName],
    ['Meter ID', reading.meterId],
    ['Reading Date', formatDate(reading.date)],
    ['Previous Reading', formatKwh(reading.previousReading)],
    ['Current Reading', formatKwh(reading.currentReading)],
    ['Consumption', formatKwh(reading.consumption)],
  ];

  const footer = canReview ? (
    isPending ? (
      <>
        <Button variant="outline" onClick={onClose}>Close</Button>
        <Button variant="danger" onClick={() => onReject(reading)}>Reject</Button>
        <Button onClick={() => onVerify(reading)}>Verify</Button>
      </>
    ) : (
      <>
        <span className="muted">This reading has already been reviewed.</span>
        <Button variant="outline" onClick={onClose}>Close</Button>
      </>
    )
  ) : (
    <Button variant="outline" onClick={onClose}>Close</Button>
  );

  return (
    <Modal title="Meter Reading Details" onClose={onClose} footer={footer}>
      <div className="detail-grid">
        {items.map(([label, value]) => (
          <div className="detail-item" key={label}>
            <span className="detail-label">{label}</span>
            <span className="detail-value">{value}</span>
          </div>
        ))}
        <div className="detail-item">
          <span className="detail-label">Status</span>
          <StatusBadge status={reading.status} />
        </div>
      </div>
    </Modal>
  );
}
