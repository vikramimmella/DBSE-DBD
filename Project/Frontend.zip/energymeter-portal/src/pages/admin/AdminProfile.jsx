import ProfileCard from '../../components/ProfileCard';

export default function AdminProfile() {
  return <ProfileCard />;
}
