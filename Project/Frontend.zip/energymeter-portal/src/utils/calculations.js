// Reusable calculation helpers. Pages never do maths inside JSX - they call these.
// Every function guards against invalid input (NaN, empty lists, division by zero).

const isNum = (v) => typeof v === 'number' && Number.isFinite(v);

// Accepts a list of numbers OR a list of reading objects ({ consumption }).
const toValues = (list) => (list || []).map((x) => (typeof x === 'number' ? x : x.consumption)).filter(isNum);

/** CONSUMPTION = current reading - previous reading (returns 0 for invalid input). */
export function calculateConsumption(currentReading, previousReading) {
  const current = Number(currentReading);
  const previous = Number(previousReading);
  if (!isNum(current) || !isNum(previous)) return 0;
  return current - previous;
}

/** Average of the consumption values. */
export function calculateAverageConsumption(list) {
  const values = toValues(list);
  if (values.length === 0) return 0;
  return values.reduce((sum, v) => sum + v, 0) / values.length;
}

export function calculateHighestConsumption(list) {
  const values = toValues(list);
  return values.length ? Math.max(...values) : 0;
}

export function calculateLowestConsumption(list) {
  const values = toValues(list);
  return values.length ? Math.min(...values) : 0;
}

/** ((current - previous) / previous) * 100. Returns null when it cannot be calculated. */
export function calculatePercentageChange(current, previous) {
  if (!isNum(current) || !isNum(previous) || previous === 0) return null;
  return ((current - previous) / previous) * 100;
}

/**
 * UNUSUAL CONSUMPTION RULE (simple threshold - NOT machine learning):
 *   A period is "unusual" when its consumption is MORE THAN 20% above the
 *   customer's normal (average) consumption.
 *     unusual  <=>  current > average * (1 + 20 / 100)
 */
export const UNUSUAL_THRESHOLD_PERCENT = 20;

export function detectUnusualConsumption(current, average, thresholdPercent = UNUSUAL_THRESHOLD_PERCENT) {
  if (!isNum(current) || !isNum(average) || average <= 0) {
    return { isUnusual: false, difference: 0, percentAbove: null, thresholdPercent };
  }
  const difference = current - average;
  const percentAbove = (difference / average) * 100;
  return { isUnusual: percentAbove > thresholdPercent, difference, percentAbove, thresholdPercent };
}

/**
 * Overall average consumption across ALL consumers.
 * Each consumer's own average is calculated first, then those averages are averaged,
 * so a consumer with more readings does not dominate the result.
 */
export function calculateOverallAverage(allReadings) {
  const byConsumer = {};
  (allReadings || []).forEach((r) => {
    if (!byConsumer[r.consumerId]) byConsumer[r.consumerId] = [];
    byConsumer[r.consumerId].push(r);
  });
  const averages = Object.values(byConsumer).map((list) => calculateAverageConsumption(list));
  return calculateAverageConsumption(averages);
}
