// A titled card that gives a Chart.js chart a fixed height (needed for responsive charts).
export default function ChartCard({ title, subtitle, height = 300, children }) {
  return (
    <div className="card">
      <div className="card-header">
        <div>
          <h3 className="card-title">{title}</h3>
          {subtitle && <p className="card-sub">{subtitle}</p>}
        </div>
      </div>
      <div className="chart-box" style={{ height }}>{children}</div>
    </div>
  );
}
