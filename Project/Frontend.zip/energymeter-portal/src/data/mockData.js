// ---------------------------------------------------------------------------
// MOCK DATA (demonstration only - all people are fictional).
// Today the app reads this through src/services/api.js.
// Later, api.js will fetch the same shapes from the Express + Sequelize + MySQL backend.
// ---------------------------------------------------------------------------
import { calculateConsumption } from '../utils/calculations';

// Consumer shape: { id, name, email, meterId, role, status }
export const consumers = [
  { id: 'C-001', name: 'Vikram Immella', email: 'consumer@example.com', meterId: 'MTR-10234', role: 'consumer', status: 'Active' },
  { id: 'C-002', name: 'Rahul Sharma', email: 'rahul@example.com', meterId: 'MTR-1001', role: 'consumer', status: 'Active' },
  { id: 'C-003', name: 'Priya Reddy', email: 'priya@example.com', meterId: 'MTR-1002', role: 'consumer', status: 'Active' },
  { id: 'C-004', name: 'Anil Kumar', email: 'anil@example.com', meterId: 'MTR-1003', role: 'consumer', status: 'Active' },
  { id: 'C-005', name: 'Sneha Iyer', email: 'sneha@example.com', meterId: 'MTR-1004', role: 'consumer', status: 'Active' },
  { id: 'C-006', name: 'Karthik Nair', email: 'karthik@example.com', meterId: 'MTR-1005', role: 'consumer', status: 'Active' },
];

export const adminUser = {
  id: 'A-001', name: 'System Administrator', email: 'admin@example.com', meterId: null, role: 'admin', status: 'Active',
};

// Months covered by the mock history (one reading per month, taken on the 28th).
const MONTHS = ['2025-10', '2025-11', '2025-12', '2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06', '2026-07', '2026-08', '2026-09'];

/**
 * Builds a reading history from a starting meter value and monthly kWh figures.
 * Each reading's previousReading is the last reading's currentReading, and
 * consumption is ALWAYS calculated (never typed in), so the data cannot contradict itself.
 * Reading shape: { id, consumerId, meterId, date, previousReading, currentReading, consumption, status }
 */
function buildReadings(consumer, startReading, monthlyKwh, statusByMonth = {}) {
  let previous = startReading;
  return MONTHS.map((month, i) => {
    const current = previous + monthlyKwh[i];
    const reading = {
      id: `R-${consumer.id.slice(2)}-${month}`,
      consumerId: consumer.id,
      meterId: consumer.meterId,
      date: `${month}-28`,
      previousReading: previous,
      currentReading: current,
      consumption: calculateConsumption(current, previous),
      status: statusByMonth[month] || 'Verified',
    };
    previous = current;
    return reading;
  });
}

const [vikram, rahul, priya, anil, sneha, karthik] = consumers;

export const initialReadings = [
  ...buildReadings(vikram, 9000, [240, 260, 230, 210, 180, 225, 240, 260, 250, 290, 280, 330], { '2026-09': 'Pending' }),
  ...buildReadings(rahul, 15000, [310, 330, 300, 300, 280, 320, 350, 390, 380, 410, 370, 390], { '2026-09': 'Pending' }),
  ...buildReadings(priya, 5000, [190, 200, 180, 170, 160, 175, 190, 210, 220, 240, 230, 250], { '2026-06': 'Rejected' }),
  ...buildReadings(anil, 22000, [500, 470, 450, 430, 410, 440, 470, 520, 560, 600, 580, 520], { '2026-09': 'Pending' }),
  ...buildReadings(sneha, 7000, [260, 250, 240, 230, 220, 250, 270, 300, 310, 330, 320, 340]),
  ...buildReadings(karthik, 11000, [150, 140, 160, 150, 140, 155, 170, 185, 190, 200, 195, 180], { '2026-08': 'Rejected', '2026-09': 'Pending' }),
];

// Small sample used only by the landing page illustration.
export const landingPreview = { meterValue: '012065', bars: [225, 240, 260, 250, 290, 280, 330] };
