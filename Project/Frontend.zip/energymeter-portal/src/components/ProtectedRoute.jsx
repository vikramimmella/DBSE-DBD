import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Frontend-only guard: not logged in -> /login; wrong role -> that user's own dashboard.
// (Real security must be enforced by the backend using JWT - this only controls what the UI shows.)
export default function ProtectedRoute({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== role) return <Navigate to={`/${user.role}/dashboard`} replace />;
  return children;
}
