import { Navigate, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import DashboardLayout from './components/DashboardLayout';
import ProtectedRoute from './components/ProtectedRoute';
import ConsumerDashboard from './pages/consumer/ConsumerDashboard';
import SubmitReading from './pages/consumer/SubmitReading';
import ReadingHistory from './pages/consumer/ReadingHistory';
import ConsumptionAnalytics from './pages/consumer/ConsumptionAnalytics';
import ConsumerProfile from './pages/consumer/ConsumerProfile';
import AdminDashboard from './pages/admin/AdminDashboard';
import MeterReadings from './pages/admin/MeterReadings';
import AdminAnalytics from './pages/admin/AdminAnalytics';
import AdminProfile from './pages/admin/AdminProfile';

export default function App() {
  return (
    <Routes>
      {/* Public */}
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />

      {/* Consumer area (protected) */}
      <Route element={<ProtectedRoute role="consumer"><DashboardLayout /></ProtectedRoute>}>
        <Route path="/consumer/dashboard" element={<ConsumerDashboard />} />
        <Route path="/consumer/submit" element={<SubmitReading />} />
        <Route path="/consumer/history" element={<ReadingHistory />} />
        <Route path="/consumer/analytics" element={<ConsumptionAnalytics />} />
        <Route path="/consumer/profile" element={<ConsumerProfile />} />
      </Route>

      {/* Admin area (protected) */}
      <Route element={<ProtectedRoute role="admin"><DashboardLayout /></ProtectedRoute>}>
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/readings" element={<MeterReadings />} />
        <Route path="/admin/analytics" element={<AdminAnalytics />} />
        <Route path="/admin/profile" element={<AdminProfile />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
