import { useMemo } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import { useReadings } from '../../context/ReadingContext';
import StatCard from '../../components/StatCard';
import ChartCard from '../../components/ChartCard';
import EmptyState from '../../components/EmptyState';
import { getAdminAnalytics } from '../../utils/analytics';
import { baseOptions, COLORS } from '../../utils/chartSetup';
import { formatKwh, formatNumber } from '../../utils/format';

// Admin analytics = the WHOLE utility dataset (consumer analytics = one consumer's own data).
export default function AdminAnalytics() {
  const { readings, consumers, getConsumerName } = useReadings();
  const a = useMemo(() => getAdminAnalytics(readings, consumers), [readings, consumers]);

  if (readings.length === 0) return <EmptyState message="No meter readings available." />;

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '62%',
    plugins: {
      legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } },
      tooltip: { callbacks: { label: (ctx) => ` ${ctx.label}: ${ctx.parsed} readings` } },
    },
  };

  return (
    <>
      <p className="note">Demonstration data: all values come from mock readings of fictional consumers. Rejected readings are excluded from consumption figures.</p>

      <div className="stat-grid cols-5">
        <StatCard label="Total Consumption" icon="bolt" tone="green" value={formatKwh(a.totalConsumption)} sub="All consumers" />
        <StatCard label="Average Consumption" icon="chart" value={formatKwh(a.averageConsumption)} sub="Per reading" />
        <StatCard label="Highest Consumption" icon="alert" tone="red" value={a.highestReading ? formatKwh(a.highestValue) : '-'} sub={a.highestReading ? getConsumerName(a.highestReading.consumerId) : ''} />
        <StatCard label="Number of Consumers" icon="users" value={formatNumber(a.consumerCount)} sub="Registered" />
        <StatCard label="Pending Readings" icon="clock" tone="amber" value={formatNumber(a.pendingCount)} sub="Awaiting verification" />
      </div>

      <div className="grid-2">
        <ChartCard title="Overall Consumption by Month" subtitle="Total kWh of all consumers combined" height={300}>
          <Bar
            options={baseOptions()}
            data={{ labels: a.byMonth.map((m) => m.label), datasets: [{ label: 'Total consumption', data: a.byMonth.map((m) => m.total), backgroundColor: COLORS.navy, borderRadius: 4 }] }}
          />
        </ChartCard>

        <ChartCard title="Top Consumers" subtitle="Highest total consumption (demo values)" height={300}>
          <Bar
            options={baseOptions({ horizontal: true })}
            data={{ labels: a.topConsumers.map((c) => c.name), datasets: [{ label: 'Total consumption', data: a.topConsumers.map((c) => c.total), backgroundColor: COLORS.green, borderRadius: 4 }] }}
          />
        </ChartCard>

        <ChartCard title="Consumer vs Overall Usage" subtitle={`Average per reading for each consumer vs the overall average (${formatKwh(a.overallAverage)})`} height={300}>
          <Bar
            options={baseOptions({ legend: true })}
            data={{
              labels: a.perConsumer.map((c) => c.name.split(' ')[0]),
              datasets: [
                { type: 'bar', label: 'Consumer average', data: a.perConsumer.map((c) => Math.round(c.average * 10) / 10), backgroundColor: COLORS.navyLight, borderRadius: 4 },
                { type: 'line', label: 'Overall average', data: a.perConsumer.map(() => Math.round(a.overallAverage * 10) / 10), borderColor: COLORS.green, borderDash: [6, 4], borderWidth: 2, pointRadius: 0 },
              ],
            }}
          />
        </ChartCard>

        <ChartCard title="Reading Status Distribution" subtitle="Number of readings by verification status" height={300}>
          <Doughnut
            options={doughnutOptions}
            data={{
              labels: ['Verified', 'Pending', 'Rejected'],
              datasets: [{ data: [a.statusCounts.Verified, a.statusCounts.Pending, a.statusCounts.Rejected], backgroundColor: [COLORS.green, COLORS.amber, COLORS.red], borderWidth: 0 }],
            }}
          />
        </ChartCard>
      </div>
    </>
  );
}
