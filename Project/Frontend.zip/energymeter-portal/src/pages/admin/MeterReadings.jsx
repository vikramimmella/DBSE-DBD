import { useMemo, useState } from 'react';
import { useReadings } from '../../context/ReadingContext';
import { useNotification } from '../../context/NotificationContext';
import Input from '../../components/Input';
import Select from '../../components/Select';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Button from '../../components/Button';
import ReadingDetailsModal from '../../components/ReadingDetailsModal';
import { filterReadings, getMonthOptions, sortReadingsDesc } from '../../utils/filters';
import { formatDate, formatKwh, formatNumber } from '../../utils/format';

const statusOptions = ['All', 'Verified', 'Pending', 'Rejected'].map((s) => ({ value: s, label: s === 'All' ? 'All statuses' : s }));

// Centralized data grid of every reading + verification workflow (Verify / Reject).
export default function MeterReadings() {
  const { readings, getConsumerName, updateReadingStatus } = useReadings();
  const { notify } = useNotification();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [month, setMonth] = useState('All');
  const [selected, setSelected] = useState(null);

  const sorted = useMemo(() => sortReadingsDesc(readings), [readings]);
  const rows = useMemo(
    () => filterReadings(sorted, { search, status, month }, getConsumerName),
    [sorted, search, status, month, getConsumerName]
  );
  const pending = readings.filter((r) => r.status === 'Pending').length;

  // Verify / Reject: updates the reading in shared state, so every table refreshes immediately.
  async function review(reading, newStatus) {
    await updateReadingStatus(reading.id, newStatus);
    setSelected(null);
    if (newStatus === 'Verified') notify('Reading verified successfully.');
    else notify('Reading rejected.', 'error');
  }

  const columns = [
    { key: 'consumer', label: 'Consumer', render: (r) => getConsumerName(r.consumerId) },
    { key: 'meterId', label: 'Meter ID' },
    { key: 'date', label: 'Date', render: (r) => formatDate(r.date) },
    { key: 'previousReading', label: 'Previous Reading', align: 'right', render: (r) => formatNumber(r.previousReading) },
    { key: 'currentReading', label: 'Current Reading', align: 'right', render: (r) => formatNumber(r.currentReading) },
    { key: 'consumption', label: 'Consumption', align: 'right', render: (r) => formatKwh(r.consumption) },
    { key: 'status', label: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { key: 'actions', label: 'Actions', render: (r) => <Button variant={r.status === 'Pending' ? 'primary' : 'ghost'} size="sm" onClick={() => setSelected(r)}>{r.status === 'Pending' ? 'Review' : 'View'}</Button> },
  ];

  return (
    <>
      <div className="card">
        <div className="toolbar">
          <Input id="search" label="Search" placeholder="Search by consumer or meter ID" value={search} onChange={(e) => setSearch(e.target.value)} />
          <Select id="status" label="Status" options={statusOptions} value={status} onChange={(e) => setStatus(e.target.value)} />
          <Select id="month" label="Month" options={getMonthOptions(readings)} value={month} onChange={(e) => setMonth(e.target.value)} />
        </div>
        <p className="table-count">Showing {rows.length} of {readings.length} readings &middot; {pending} pending verification</p>
        <DataTable columns={columns} rows={rows} empty={readings.length === 0 ? 'No meter readings available.' : 'No readings match your search.'} />
      </div>

      {selected && (
        <ReadingDetailsModal
          reading={selected}
          consumerName={getConsumerName(selected.consumerId)}
          canReview
          onClose={() => setSelected(null)}
          onVerify={(r) => review(r, 'Verified')}
          onReject={(r) => review(r, 'Rejected')}
        />
      )}
    </>
  );
}
