import { createContext, useContext, useEffect, useState } from 'react';
import * as api from '../services/api';

// Single source of truth for consumers + readings. Everything else (dashboard cards, tables,
// analytics) is DERIVED from `readings`, so a new reading or a status change updates every page.
const ReadingContext = createContext(null);

export function ReadingProvider({ children }) {
  const [consumers, setConsumers] = useState([]);
  const [readings, setReadings] = useState([]);

  useEffect(() => {
    api.getConsumers().then(setConsumers);
    api.getReadings().then(setReadings);
  }, []);

  const getConsumerName = (id) => consumers.find((c) => c.id === id)?.name || 'Unknown';

  async function addReading(payload) {
    const saved = await api.submitReading(payload);
    setReadings((prev) => [...prev, saved]);
    return saved;
  }

  async function updateReadingStatus(id, status) {
    await api.updateReadingStatus(id, status);
    setReadings((prev) => prev.map((r) => (r.id === id ? { ...r, status } : r)));
  }

  return (
    <ReadingContext.Provider value={{ consumers, readings, getConsumerName, addReading, updateReadingStatus }}>
      {children}
    </ReadingContext.Provider>
  );
}

export const useReadings = () => useContext(ReadingContext);
