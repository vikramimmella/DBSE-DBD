// variant: primary | outline | danger | ghost      size: md | sm
export default function Button({ variant = 'primary', size = 'md', className = '', children, ...props }) {
  return (
    <button className={`btn btn-${variant} ${size === 'sm' ? 'btn-sm' : ''} ${className}`} {...props}>
      {children}
    </button>
  );
}
