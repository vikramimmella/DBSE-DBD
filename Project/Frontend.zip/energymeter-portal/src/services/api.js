// ---------------------------------------------------------------------------
// API SERVICE LAYER  (the ONLY place that should know where data comes from)
//
//   Now   : React component -> context -> api.js -> mockData.js
//   Later : React component -> context -> api.js -> Express API -> Sequelize -> MySQL
//
// Every function returns a Promise, exactly like a real fetch()/axios call,
// so components/contexts will not need to change when the backend is connected.
// To connect the backend: replace the body of each function with the commented example.
// ---------------------------------------------------------------------------
import { consumers, adminUser, initialReadings } from '../data/mockData';
import { calculateConsumption } from '../utils/calculations';

// const BASE_URL = 'http://localhost:5000/api';   // <-- future Express server
// const authHeader = () => ({ Authorization: `Bearer ${localStorage.getItem('energymeter_token')}` });

/** POST /auth/login -> { user, token }  (token would be a JWT) */
export async function login({ email, password, role }) {
  // FUTURE: const res = await fetch(`${BASE_URL}/auth/login`, { method: 'POST',
  //   headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password, role }) });
  //   if (!res.ok) throw new Error('Invalid credentials'); return res.json();
  const mail = email.trim().toLowerCase();
  const pool = role === 'admin' ? [adminUser] : consumers;
  const user = pool.find((u) => u.email === mail);
  if (!user) {
    const hint = role === 'admin' ? adminUser.email : 'consumer@example.com';
    throw new Error(`No demo ${role} account for that email. Try ${hint}.`);
  }
  return { user, token: 'demo-token-not-a-real-jwt' }; // password is ignored in the demo
}

/** GET /consumers */
export async function getConsumers() {
  // FUTURE: return (await fetch(`${BASE_URL}/consumers`, { headers: authHeader() })).json();
  return consumers.map((c) => ({ ...c }));
}

/** GET /readings  (admin: all readings, consumer: own readings) */
export async function getReadings() {
  // FUTURE: return (await fetch(`${BASE_URL}/readings`, { headers: authHeader() })).json();
  return initialReadings.map((r) => ({ ...r }));
}

/** POST /readings  - body: { consumerId, meterId, date, previousReading, currentReading } */
export async function submitReading({ consumerId, meterId, date, previousReading, currentReading }) {
  // FUTURE: POST the body and return the saved row created by Sequelize.
  return {
    id: `R-${Date.now()}`,
    consumerId,
    meterId,
    date,
    previousReading: Number(previousReading),
    currentReading: Number(currentReading),
    consumption: calculateConsumption(currentReading, previousReading), // calculated, never typed in
    status: 'Pending',
  };
}

/** PATCH /readings/:id/status  - body: { status: 'Verified' | 'Rejected' } */
export async function updateReadingStatus(id, status) {
  // FUTURE: return (await fetch(`${BASE_URL}/readings/${id}/status`, { method: 'PATCH',
  //   headers: { 'Content-Type': 'application/json', ...authHeader() }, body: JSON.stringify({ status }) })).json();
  return { id, status };
}

/** GET /analytics - placeholder. The frontend currently derives analytics from readings
 *  (src/utils/analytics.js). A backend could instead return pre-aggregated SQL results here. */
export async function getAnalytics() {
  // FUTURE: return (await fetch(`${BASE_URL}/analytics`, { headers: authHeader() })).json();
  return null;
}
