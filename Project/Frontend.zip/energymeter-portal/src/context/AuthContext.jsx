import { createContext, useContext, useState } from 'react';
import * as api from '../services/api';

// DEMO AUTH: the logged-in user is kept in React state and localStorage so a page refresh keeps you logged in.
// FUTURE (JWT): api.login() will return { user, token }. Save the token here (localStorage) and send it
// in the Authorization header from api.js. Nothing else in the app needs to change.
const AuthContext = createContext(null);
const STORAGE_KEY = 'energymeter_user';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY));
    } catch {
      return null;
    }
  });

  async function login(credentials) {
    const { user: loggedIn } = await api.login(credentials); // throws an Error if login fails
    setUser(loggedIn);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(loggedIn));
    return loggedIn;
  }

  function logout() {
    setUser(null);
    localStorage.removeItem(STORAGE_KEY);
  }

  // Local-only profile edit (later: PUT /profile).
  function updateProfile(changes) {
    const updated = { ...user, ...changes };
    setUser(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }

  return <AuthContext.Provider value={{ user, role: user?.role, login, logout, updateProfile }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
